    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.min.css')); ?>" />
<?php /**PATH E:\pengganti-c\laragon\www\sourcode\portfolio-laravel\resources\views/layouts/template/Css.blade.php ENDPATH**/ ?>