   <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
       <ul id="sidebarnav">
           <li class="nav-small-cap">
               <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
               <span class="hide-menu">Home</span>
           </li>
           <li class="sidebar-item">
               <a class="sidebar-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('dashboard')); ?>"
                   aria-expanded="false">
                   <span>
                       <i class="ti ti-layout-dashboard"></i>
                   </span>
                   <span class="hide-menu">Dashboard</span>
               </a>
           </li>
       </ul>
   </nav>
<?php /**PATH E:\pengganti-c\laragon\www\sourcode\portfolio-laravel\resources\views/layouts/template/Sidebar.blade.php ENDPATH**/ ?>